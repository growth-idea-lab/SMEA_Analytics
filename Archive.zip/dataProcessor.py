import MySQLdb

logger = logHelper.getDebugLogger()

def getBalanceSheetData(userId):
    sql_txt = ''
    if userId:
        sql_txt = """ where userId in ('%s') """ % userId

    sql = """
                    select * from Balance_Sheet;
                    """ % sql_txt

    results = executeStatementAndGetData(sql)

    localData = {}

    for row in results:
        d = {}
        d['FYCODE'] = row[0]
        d['CASH'] = row[1]
        d['DEPOSIT'] = row[2]
        d['AR'] = row[3]
        d['INVENTORY'] = row[4]
        d['PRE_EXPENSES'] = row[5]
        d['OTHER_CURRENT_ASSETS'] = row[6]
        d['PPAE'] = row[0]
        d['OLTA'] = row[1]
        d['INTANGIBLE_ASSETS'] = row[2]
        d['GOODWILL'] = row[3]
        d['TLTA'] = row[4]
        d['TOTAL_ASSETS'] = row[5]
        d['OTHER_CURRENT_ASSETS'] = row[6]
        d['AP'] = row[0]
        d['REVOLVING_DEBIT'] = row[1]
        d['ITP'] = row[2]
        d['CPOLTD'] = row[3]
        d['OCL'] = row[4]
        d['TCL'] = row[5]
        d['TOEAL'] = row[6]

        localData.append(d)

    logger.debug(localData)
    return localData



def getIndustryBalanceSheet():
    sql = """
        select * from Balance_Sheet_Standard;
        """
    results = executeStatementAndGetData(sql)

    localData = {}

    for row in results:
        d = {}
        d['FYCODE'] = row[0]
        d['CASH'] = row[1]
        d['DEPOSIT'] = row[2]
        d['AR'] = row[3]
        d['INVENTORY'] = row[4]
        d['PRE_EXPENSES'] = row[5]
        d['OTHER_CURRENT_ASSETS'] = row[6]
        d['PPAE'] = row[0]
        d['OLTA'] = row[1]
        d['INTANGIBLE_ASSETS'] = row[2]
        d['GOODWILL'] = row[3]
        d['TLTA'] = row[4]
        d['TOTAL_ASSETS'] = row[5]
        d['OTHER_CURRENT_ASSETS'] = row[6]
        d['AP'] = row[0]
        d['REVOLVING_DEBIT'] = row[1]
        d['ITP'] = row[2]
        d['CPOLTD'] = row[3]
        d['OCL'] = row[4]
        d['TCL'] = row[5]
        d['TOEAL'] = row[6]

        localData.append(d)

    logger.debug(localData)
    return localData


def getIncomeSheetStandard():
    sql = """
            select * from Income_Sheet;
            """
    results = executeStatementAndGetData(sql)

    localData = {}

    for row in results:
        d = {}
        d['FYCODE'] = row[0]
        d['USERID'] = row[1]
        d['REVENUE'] = row[2]
        d['BEG_INVENTORY'] = row[3]
        d['PURCHASES'] = row[4]
        d['FIE'] = row[5]
        d['END_INVENTORY'] = row[6]
        d['BOM'] = row[7]
        d['LC'] = row[8]
        d['SCE'] = row[9]
        d['COGS'] = row[10]
        d['GROSS_PROFIT'] = row[11]
        d['BDE'] = row[12]
        d['FUEL_EXP'] = row[13]
        d['CONV_EXP'] = row[14]
        d['TELE_EXP'] = row[15]
        d['SAAE'] = row[16]
        d['ELEC_CHARGES'] = row[17]
        d['VEHICLE_MAINT'] = row[18]
        d['MACHINE_MAINT'] = row[19]
        d['RENT'] = row[20]
        d['CONSUMABLES'] = row[21]
        d['BANK_CHARGES'] = row[22]
        d['OOE'] = row[23]
        d['EBITDA'] = row[24]
        d['DEPR'] = row[25]
        d['AMORT_EXP'] = row[26]
        d['OTHER_EXP'] = row[27]
        d['OPER_PROFIT'] = row[28]
        d['BIE'] = row[29]
        d['OIE'] = row[30]
        d['TIE'] = row[31]
        d['BII'] = row[32]
        d['OII'] = row[33]
        d['TII'] = row[34]
        d['NIBT'] = row[35]
        d['ITE'] = row[36]
        d['NET_INCOME'] = row[37]


        localData.append(d)


    logger.debug(localData)
    return localData



def getIncomeSheetUser(userId):

    sql_txt = ''
    if userId :
        sql_txt = """ where userId in ('%s') """ % userId

    sql = """
                select * from Income_Sheet;
                """% sql_txt


    results = executeStatementAndGetData(sql)

    localData = {}

    for row in results:
        d = {}
        d['FYCODE'] = row[0]
        d['USERID'] = row[1]
        d['REVENUE'] = row[2]
        d['BEG_INVENTORY'] = row[3]
        d['PURCHASES'] = row[4]
        d['FIE'] = row[5]
        d['END_INVENTORY'] = row[6]
        d['BOM'] = row[7]
        d['LC'] = row[8]
        d['SCE'] = row[9]
        d['COGS'] = row[10]
        d['GROSS_PROFIT'] = row[11]
        d['BDE'] = row[12]
        d['FUEL_EXP'] = row[13]
        d['CONV_EXP'] = row[14]
        d['TELE_EXP'] = row[15]
        d['SAAE'] = row[16]
        d['ELEC_CHARGES'] = row[17]
        d['VEHICLE_MAINT'] = row[18]
        d['MACHINE_MAINT'] = row[19]
        d['RENT'] = row[20]
        d['CONSUMABLES'] = row[21]
        d['BANK_CHARGES'] = row[22]
        d['OOE'] = row[23]
        d['EBITDA'] = row[24]
        d['DEPR'] = row[25]
        d['AMORT_EXP'] = row[26]
        d['OTHER_EXP'] = row[27]
        d['OPER_PROFIT'] = row[28]
        d['BIE'] = row[29]
        d['OIE'] = row[30]
        d['TIE'] = row[31]
        d['BII'] = row[32]
        d['OII'] = row[33]
        d['TII'] = row[34]
        d['NIBT'] = row[35]
        d['ITE'] = row[36]
        d['NET_INCOME'] = row[37]

        localData.append(d)

    logger.debug(localData)
    return localData


def getChartsForUser(userId):
    sql_txt = ''
    if userId:
        sql_txt = """ where userId in ('%s') """ % userId

    sql = """
                    select * from User_Charts_Ratios;
                    """ % sql_txt

    results = executeStatementAndGetData(sql)

    localData = {}

    for row in results:
        d = {}
        d['FYCODE'] = row[0]
        d['USERID'] = row[1]
        d['REVENUE'] = row[2]


