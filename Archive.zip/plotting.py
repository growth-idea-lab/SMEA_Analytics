def plotAllCharts (userList,IndustryList,chartName,userId):
    plt.plot(Year_List, userList,linestyle='solid',label="Company standard")
    plt.plot(Year_List, IndustryList,linestyle='dashed',label="Industry standard")
    plt.xlabel('Year')
    plt.title('Revenue ( 1e9=10^9=1000000000 )')
    plt.xticks(np.arange(min(Year_List), max(Year_List)+1, 1.0))
    plt.legend(loc='best')
    plt.savefig(chartName)
    document.add_picture(chartName+'.png', width=Inches(4))
    plt.close()



    send_email(true,userId)




