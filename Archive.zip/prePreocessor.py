# //TODO : Rewrite this



  # def preProcessor (userId,sectorId):
  #
  #
  #
  #
  #
  #
  #   Year_List = list()
  #   Current_Ratio_List = list()
  #   Current_Ratio_Industry_List = list()
  #
  #   Quick_Ratio_List = list()
  #   Quick_Ratio_Industry_List = list()
  #
  #   Return_On_Assets_List = list()
  #   Return_On_Assets_Industry_List = list()
  #
  #   Return_On_Equity_List = list()
  #   Return_On_Equity_Industry_List = list()
  #
  #   Gross_Margin_List = list()
  #   Gross_Margin_Industry_List = list()
  #
  #   Profit_Margin_List = list()
  #   Profit_Margin_Industry_List = list()
  #
  #   Operating_Margin_List = list()
  #   Operating_Margin_Industry_List = list()
  #
  #   Asset_TurnOver_List = list()
  #   Asset_TurnOver_Industry_List = list()
  #
  #   Accounts_Receivable_Turnover_List = list()
  #   Accounts_Receivable_Turnover_Industry_List = list()
  #
  #   Accounts_Payable_Days_List = list()
  #   Accounts_Payable_Days_Industry_List = list()
  #
  #   Average_Days_Sales_List = list()
  #   Average_Days_Sales_Industry_List = list()
  #
  #   Days_Receivable_List = list()
  #   Days_Receivable_Industry_List = list()
  #
  #   Inventory_TurnOver_List = list()
  #   Inventory_TurnOver_Industry_List = list()
  #
  #   Inventory_TurnOver_Period_List = list()
  #   Inventory_TurnOver_Period_Industry_List = list()
  #
  #   Fixed_Asset_TurnOver_List = list()
  #   Fixed_Asset_TurnOver_Industry_List = list()
  #
  #   Working_Capital_TurnOver_List = list()
  #   Working_Capital_TurnOver_Industry_List = list()
  #
  #   Debt_Ratio_List = list()
  #   Debt_ratio_Industry_List = list()
  #
  #   Debt_Equity_Ratio_List = list()
  #   Debt_Equity_Ratio_Industry_List = list()
  #
  #   # Common size analysis
  #   Revenue_List = list()
  #   Revenue_Industry_List = list()
  #
  #   Beginning_Inventory_Percentage_List = list()
  #   Beginning_Inventory_Industry_Percentage_List = list()
  #
  #   Purchases_Percentage_List = list()
  #   Purchases_Industry_Percentage_List = list()
  #
  #   Freight_Expenses_Percentage_List = list()
  #   Freight_Expenses_Industry_Percentage_List = list()
  #
  #   Ending_Inventory_Percentage_List = list()
  #   Ending_Inventory_Industry_Percentage_List = list()
  #
  #   Bill_Of_Materials_Percentage_List = list()
  #   Bill_Of_Materials_Industry_Percentage_List = list()
  #
  #   Labour_Charges_Percentage_List = list()
  #   Labour_Charges_Per_Working_Hour_List = list()
  #
  #   Labour_Charges_Industry_Percentage_List = list()
  #   Labour_Charges_Industry_Per_Working_Hour_List=list()
  #
  #   Sub_Contract_Expenses_Percentage_List = list()
  #   Sub_Contract_Expenses_Industry_Percentage_List = list()
  #
  #   Cost_Of_Goods_Sold_Percentage_List = list()
  #   Cost_Of_Goods_Sold_Percentage_Industry_List = list()
  #
  #   Gross_Profit_Percentage_List = list()
  #   Gross_Profit_Industry_Percentage_List = list()
  #
  #   Business_Development_Expenses_Percentage_List = list()
  #   Business_Development_Expenses_Industry_Percentage_List = list()
  #
  #   Fuel_Expenses_Percentage_List = list()
  #   Fuel_Expenses_Industry_Percentage_List = list()
  #
  #   Conveyance_Expenses_Percentage_List = list()
  #   Conveyance_Expenses_Industry_Percentage_List = list()
  #
  #   Telephone_Expenses_Percentage_List = list()
  #   Telephone_Expenses_Industry_Percentage_List = list()
  #
  #   Selling_And_Admin_Expenses_Percentage_List = list()
  #   Selling_And_Admin_Expenses_Industry_Percentage_List = list()
  #
  #   Electricity_Expenses_Percentage_List = list()
  #   Electricity_Expenses_Industry_Percentage_List = list()
  #   Vehicle_Maintenance_Percentage_List = list()
  #   Vehicle_Maintenance_Industry_Percentage_List = list()
  #   Machine_Maintenance_Percentage_List = list()
  #   Machine_Maintenance_Industry_Percentage_List = list()
  #   Rent_Percentage_List = list()
  #   Rent_Industry_Percentage_List = list()
  #   Consumables_Percentage_List = list()
  #   Consumables_Industry_Percentage_List = list()
  #   Bank_Charges_Percentage_List = list()
  #   Bank_Charges_Industry_Percentage_List = list()
  #   Other_Operating_Expenses_Percentage_List = list()
  #   Other_Operating_Expenses_Industry_Percentage_List = list()
  #   EBITDA_Percentage_List = list()
  #   EBITDA_Industry_Percentage_List = list()
  #   Depreciation_Expense_Percentage_List = list()
  #   Depreciation_Industry_Expense_Percentage_List = list()
  #   Amortization_Expense_Percentage_List = list()
  #   Amortization_Expense_Industry_Percentage_List = list()
  #   Operating_Profit_Percentage_List = list()
  #   Operating_Profit_Industry_Percentage_List = list()
  #   Bank_Interest_Expense_Percentage_List = list()
  #   Bank_Interest_Expense_Industry_Percentage_List = list()
  #   Other_Interest_Expense_Percentage_List = list()
  #   Other_Interest_Expense_Industry_Percentage_List = list()
  #   Total_Interest_Expense_Percentage_List = list()
  #   Total_Interest_Expense_Industry_Percentage_List = list()
  #   Interest_Expense_Per_Working_Hour_List = list()
  #   Interest_Expense_Industry_Per_Working_Hour_List=list()
  #   Other_Expenses_Percentage_List = list()
  #   Other_Expenses_Industry_Percentage_List = list()
  #   Bank_Interest_Income_Percentage_List = list()
  #   Bank_Interest_Income_Industry_Percentage_List = list()
  #   other_income_Percentage_List = list()
  #   other_income_Industry_Percentage_List = list()
  #   Total_Interest_Income_Percentage_List = list()
  #   Total_Interest_Income_Industry_Percentage_List = list()
  #   Net_Income_Before_Taxes_Percentage_List = list()
  #   Net_Income_Before_Taxes_Industry_Percentage_List = list()
  #   Income_Tax_Expense_Percentage_List = list()
  #   Income_Tax_Expense_Industry_Percentage_List = list()
  #   Net_Income_Percentage_List = list()
  #   Net_Income_Industry_Percentage_List = list()
  #
  #   # Asset trend analysis list
  #   Cash_and_Cash_Equivalents_list = list()
  #   Cash_and_Cash_Equivalents_Industry_list = list()
  #   Cash_and_Cash_Equivalents_percentage_change_list = list()
  #   Deposit_list = list()
  #   Deposit_percentage_change_list = list()
  #   Accounts_Receivable_List = list()
  #   Accounts_Receivable_percentage_change_List = list()
  #   Inventory_List = list()
  #   Inventory_Industry_List = list()
  #
  #
  #
  #
  #   Inventory_percentage_change_List = list()
  #   Prepaid_Expenses_List = list()
  #   Prepaid_Expenses_percentage_change_List = list()
  #   Other_Current_Assets_List = list()
  #   Other_Current_Assets_percentage_change_List = list()
  #   Total_Current_Assets_List = list()
  #   Total_Current_Assets_Industry_List = list()
  #   Total_Current_Assets_percentage_change_List = list()
  #   Property_Plant_And_Equipment_percentage_change_List = list()
  #   Other_Long_Term_Assets_percentage_change_List = list()
  #   Intangible_Assets_percentage_change_List = list()
  #   Good_Will_percentage_change_List = list()
  #   Total_Long_Term_Assets_percentage_change_List = list()
  #   Total_Assets_percentage_change_List = list()
  #
  #
  #
  #   number_of_years = 0
  #   for number in range(1, 5):
  #       Total_Equity = Balance_Sheet[number][39]
  #       if Total_Equity == 0:
  #           number_of_years = number_of_years
  #       else:
  #           number_of_years = number_of_years + 1
  #   print(number_of_years)
  #   for Col in range(1, number_of_years+1):
  #       Year = Balance_Sheet[Col][0]
  #       Year_List.append(Year)
  #       Current_Assets = Balance_Sheet[Col][8]
  #       Current_Assets_Industry = Balance_Sheet_Industry[Col][8]
  #       Current_Liabilities = Balance_Sheet[Col][26]
  #       Current_Liabilities_Industry = Balance_Sheet_Industry[Col][26]
  #       # Current_Ratio
  #       Current_Ratio = Current_Assets/Current_Liabilities
  #       Current_Ratio_Industry = Current_Assets_Industry/Current_Liabilities_Industry
  #       # Appending the ratio to the list
  #       Current_Ratio_List.append(Current_Ratio)
  #       Current_Ratio_Industry_List.append(Current_Ratio_Industry)
  #       Inventory = Balance_Sheet[Col][4]
  #       Quick_Assets = Current_Assets-Inventory
  #       Inventory_Industry = Balance_Sheet_Industry[Col][4]
  #       Quick_Assets_Industry = Current_Assets_Industry-Inventory_Industry
  #       # Quick Ratio
  #       Quick_Ratio = Quick_Assets/Current_Liabilities
  #       Quick_Ratio_Industry = Quick_Assets_Industry/Current_Liabilities_Industry
  #       # Appending the ratio to the list
  #       Quick_Ratio_List.append(Quick_Ratio)
  #       Quick_Ratio_Industry_List.append(Quick_Ratio_Industry)
  #       Net_Income = ProfitAndLossSheet[Col][51]
  #       Net_Income_Industry = ProfitAndLossSheet_Industry[Col][51]
  #       Total_Assets = Balance_Sheet[Col][18]
  #       Total_Assets_Industry = Balance_Sheet_Industry[Col][18]
  #       # Return On Assets
  #       Return_On_Assets = (Net_Income/Total_Assets)*100
  #       Return_On_Assets_Industry = (Net_Income_Industry/Total_Assets_Industry)*100
  #       # Appending the ratio to the list
  #       Return_On_Assets_List.append(Return_On_Assets)
  #       Return_On_Assets_Industry_List.append(Return_On_Assets_Industry)
  #       Owners_Equity = Balance_Sheet[Col][37]
  #       Owners_Equity_Industry = Balance_Sheet_Industry[Col][37]
  #       # Return On Equity
  #       Return_On_Equity = (Net_Income/Owners_Equity)*100
  #       Return_On_Equity_Industry = (Net_Income_Industry/Owners_Equity_Industry)*100
  #       # Appending the ratio to the list
  #       Return_On_Equity_List.append(Return_On_Equity)
  #       Return_On_Equity_Industry_List.append(Return_On_Equity_Industry)
  #       Gross_Profit = ProfitAndLossSheet[Col][11]
  #       Gross_Profit_Industry = ProfitAndLossSheet_Industry[Col][11]
  #       Revenue = ProfitAndLossSheet[Col][1]
  #       Revenue_Industry = ProfitAndLossSheet_Industry[Col][1]
  #       # Gross Margin
  #       Gross_Margin = (Gross_Profit/Revenue)*100
  #       Gross_Margin_Industry = (Gross_Profit_Industry/Revenue_Industry)*100
  #       # Appending the ratio to the list
  #       Gross_Margin_List.append(Gross_Margin)
  #       Gross_Margin_Industry_List.append(Gross_Margin_Industry)
  #       # Profit Margin
  #       Profit_Margin = (Net_Income/Revenue)*100
  #       Profit_Margin_Industry = (Net_Income_Industry/Revenue_Industry)*100
  #       # Appending the ratio to the list
  #       Profit_Margin_List.append(Profit_Margin)
  #       Profit_Margin_Industry_List.append(Profit_Margin_Industry)
  #       Operating_Income = ProfitAndLossSheet[Col][35]
  #       Operating_Income_Industry = ProfitAndLossSheet_Industry[Col][35]
  #       # Operating Margin
  #       Operating_Margin = (Operating_Income/Revenue)*100
  #       Operating_Margin_Industry = (Operating_Income_Industry/Revenue_Industry)*100
  #       # Appending the ratio to the list
  #       Operating_Margin_List.append(Operating_Margin)
  #       Operating_Margin_Industry_List.append(Operating_Margin_Industry)
  #       # Asset Turn Over ratio
  #       Asset_TurnOver = Revenue/Total_Assets
  #       Asset_TurnOver_Industry = Revenue_Industry/Total_Assets_Industry
  #       # Appending the ratio to the list
  #       Asset_TurnOver_List.append(Asset_TurnOver)
  #       Asset_TurnOver_Industry_List.append(Asset_TurnOver_Industry)
  #       Ending_Accounts_Receivable = Balance_Sheet[Col][3]
  #       Ending_Accounts_Receivable_Industry = Balance_Sheet_Industry[Col][3]
  #       Beginning_Accounts_Receivable = Balance_Sheet[Col+1][3]
  #       Beginning_Accounts_Receivable_Industry = Balance_Sheet_Industry[Col+1][3]
  #       if Beginning_Accounts_Receivable == 0:
  #           Beginning_Accounts_Receivable = Ending_Accounts_Receivable
  #       Average_Accounts_Receivable = (Ending_Accounts_Receivable + Beginning_Accounts_Receivable)/2
  #       if Beginning_Accounts_Receivable_Industry == 0:
  #           Beginning_Accounts_Receivable_Industry = Ending_Accounts_Receivable_Industry
  #       Average_Accounts_Receivable_Industry = (Ending_Accounts_Receivable_Industry + Beginning_Accounts_Receivable_Industry)/2
  #       # Accounts Receivable Turn Over
  #       Accounts_Receivable_Turnover = Revenue/Average_Accounts_Receivable
  #       Accounts_receivable_Turnover_Industry = Revenue_Industry/Average_Accounts_Receivable_Industry
  #       # Appending the ratio to the list
  #       Accounts_Receivable_Turnover_List.append(Accounts_Receivable_Turnover)
  #       Accounts_Receivable_Turnover_Industry_List.append(Accounts_receivable_Turnover_Industry)
  #       # Average Days Sales
  #       Average_Days_Sales = Revenue/365
  #       Average_Days_Sales_Industry = Revenue_Industry/365
  #       # Appending the ratio to the list
  #       Average_Days_Sales_List.append(Average_Days_Sales)
  #       Average_Days_Sales_Industry_List.append(Average_Days_Sales_Industry)
  #       # Days Receivable
  #       Days_Receivable = Ending_Accounts_Receivable/Average_Days_Sales
  #       Days_Receivable_Industry = Ending_Accounts_Receivable_Industry/Average_Days_Sales_Industry
  #       # Appending the ratio to the list
  #       Days_Receivable_List.append(Days_Receivable)
  #       Days_Receivable_Industry_List.append(Days_Receivable_Industry)
  #       Cost_Of_Goods_Sold = ProfitAndLossSheet[Col][10]
  #       Cost_Of_Goods_Sold_Industry = ProfitAndLossSheet_Industry[Col][10]
  #       Ending_Inventory = ProfitAndLossSheet[Col][6]
  #       Ending_Inventory_Industry = Balance_Sheet_Industry[Col][4]
  #       Beginning_Inventory = ProfitAndLossSheet_Industry[Col][3]
  #       Beginning_Inventory_Industry = Balance_Sheet_Industry[Col+1][4]
  #       Average_Inventory = (Ending_Inventory + Beginning_Inventory)/2
  #       if Beginning_Inventory_Industry == 0:
  #           Beginning_Inventory_Industry = Ending_Inventory_Industry
  #       Average_Inventory_Industry = (Ending_Inventory_Industry + Beginning_Inventory_Industry) / 2
  #       # Inventory Turn Over
  #       Inventory_TurnOver = Cost_Of_Goods_Sold/Average_Inventory
  #       Inventory_TurnOver_Industry = Cost_Of_Goods_Sold_Industry/Average_Inventory_Industry
  #       # Appending the ratio to the list
  #       Inventory_TurnOver_List.append(Inventory_TurnOver)
  #       Inventory_TurnOver_Industry_List.append(Inventory_TurnOver_Industry)
  #       # Inventory Turn Over Period
  #       Inventory_TurnOver_Period = 365/Inventory_TurnOver
  #       Inventory_TurnOver_Period_Industry = 365/Inventory_TurnOver_Industry
  #       # Appending the ratio to the list
  #       Inventory_TurnOver_Period_List.append(Inventory_TurnOver_Period)
  #       Inventory_TurnOver_Period_Industry_List.append(Inventory_TurnOver_Period_Industry)
  #       # Fixed Asset Turn Over
  #       Fixed_Asset_TurnOver = Cost_Of_Goods_Sold/Total_Assets
  #       Fixed_Asset_TurnOver_Industry = Cost_Of_Goods_Sold_Industry/Total_Assets_Industry
  #       # Appending the ratio to the list
  #       Fixed_Asset_TurnOver_List.append(Fixed_Asset_TurnOver)
  #       Fixed_Asset_TurnOver_Industry_List.append(Fixed_Asset_TurnOver_Industry)
  #       # Working Capital Turn Over
  #       Working_Capital_TurnOver = Revenue/(Current_Assets - Current_Liabilities)
  #       Working_Capital_TurnOver_Industry = Revenue_Industry/(Current_Assets_Industry-Current_Liabilities_Industry)
  #       # Appending the ratio to the list
  #       Working_Capital_TurnOver_List.append(Working_Capital_TurnOver)
  #       Working_Capital_TurnOver_Industry_List.append(Working_Capital_TurnOver_Industry)
  #       Total_Liabilities = Balance_Sheet[Col][33]
  #       Total_Liabilities_Industry = Balance_Sheet_Industry[Col][33]
  #       # Debt Ratio
  #       Debt_Ratio = Total_Liabilities/Total_Assets
  #       Debt_Ratio_Industry = Total_Liabilities_Industry/Total_Assets_Industry
  #       # Appending the ratio to the list
  #       Debt_Ratio_List.append(Debt_Ratio)
  #       Debt_ratio_Industry_List.append(Debt_Ratio_Industry)
  #       # Debt to Equity Ratio
  #       Debt_Equity_Ratio = Total_Assets/Owners_Equity
  #       Debt_Equity_Ratio_Industry = Total_Assets_Industry/Owners_Equity_Industry
  #       # Appending the ratio to the list
  #       Debt_Equity_Ratio_List.append(Debt_Equity_Ratio)
  #       Debt_Equity_Ratio_Industry_List.append(Debt_Equity_Ratio_Industry)
  #
  #       # Common Size Analysis
  #       # Appending the revenue to the list
  #       Revenue_List.append(Revenue)
  #       Revenue_Industry_List.append(Revenue_Industry)
  #       # as a % of sales
  #       Beginning_Inventory_Percentage = (Beginning_Inventory/Revenue)*100
  #       Beginning_Inventory_Percentage_List.append(Beginning_Inventory_Percentage)
  #
  #       Beginning_Inventory_Industry_Percentage = (Beginning_Inventory_Industry/Revenue_Industry)*100
  #       Beginning_Inventory_Industry_Percentage_List.append(Beginning_Inventory_Industry_Percentage)
  #
  #       Purchases = ProfitAndLossSheet[Col][4]
  #       Purchases_Percentage = (Purchases/Revenue)*100
  #       Purchases_Percentage_List.append(Purchases_Percentage)
  #
  #       Purchases_Industry = ProfitAndLossSheet_Industry[Col][4]
  #       Purchases_Industry_Percentage = (Purchases_Industry/Revenue_Industry)*100
  #       Purchases_Industry_Percentage_List.append(Purchases_Industry_Percentage)
  #
  #       Freight_Expenses = ProfitAndLossSheet[Col][5]
  #       Freight_Expenses_Percentage = (Freight_Expenses/Revenue)*100
  #       Freight_Expenses_Percentage_List.append(Freight_Expenses_Percentage)
  #
  #       Freight_Expenses_Industry = ProfitAndLossSheet_Industry[Col][5]
  #       Freight_Expenses_Industry_Percentage = (Freight_Expenses_Industry/Revenue_Industry)*100
  #       Freight_Expenses_Industry_Percentage_List.append(Freight_Expenses_Industry_Percentage)
  #
  #       Ending_Inventory_Percentage = (Ending_Inventory/Revenue)*100
  #       Ending_Inventory_Percentage_List.append(Ending_Inventory_Percentage)
  #
  #       Ending_Inventory_Industry_Percentage = (Ending_Inventory_Industry/Revenue_Industry)*100
  #       Ending_Inventory_Industry_Percentage_List.append(Ending_Inventory_Industry_Percentage)
  #
  #       Bill_Of_Materials = ProfitAndLossSheet[Col][7]
  #       Bill_Of_Materials_Percentage = (Bill_Of_Materials/Revenue)*100
  #       Bill_Of_Materials_Percentage_List.append(Bill_Of_Materials_Percentage)
  #
  #       Bill_Of_Materials_Industry = ProfitAndLossSheet_Industry[Col][7]
  #       Bill_Of_Materials_Industry_Percentage = (Bill_Of_Materials_Industry/Revenue_Industry)*100
  #       Bill_Of_Materials_Industry_Percentage_List.append(Bill_Of_Materials_Industry_Percentage)
  #
  #       Labour_Charges = ProfitAndLossSheet[Col][8]
  #       Labour_Charges_Percentage = (Labour_Charges/Revenue)*100
  #       Labour_Charges_Percentage_List.append(Labour_Charges_Percentage)
  #
  #       Labour_Charges_Industry = ProfitAndLossSheet_Industry[Col][8]
  #       Labour_Charges_Industry_Percentage = (Labour_Charges/Revenue)*100
  #       Labour_Charges_Industry_Percentage_List.append(Labour_Charges_Industry_Percentage)
  #
  #       Labour_Charges_Per_Working_Hour = Labour_Charges/2592
  #       Labour_Charges_Per_Working_Hour_List.append(Labour_Charges_Per_Working_Hour)
  #
  #       Labour_Charges_Industry_Per_Working_Hour = Labour_Charges_Industry/2592
  #       Labour_Charges_Industry_Per_Working_Hour_List.append(Labour_Charges_Industry_Per_Working_Hour)
  #
  #       Sub_Contract_Expenses = ProfitAndLossSheet[Col][9]
  #       Sub_Contract_Expenses_Percentage = (Sub_Contract_Expenses/Revenue)*100
  #       Sub_Contract_Expenses_Percentage_List.append(Sub_Contract_Expenses_Percentage)
  #
  #       Sub_Contract_Expenses_Industry = ProfitAndLossSheet[Col][9]
  #       Sub_Contract_Expenses_Industry_Percentage = (Sub_Contract_Expenses_Industry / Revenue_Industry) * 100
  #       Sub_Contract_Expenses_Industry_Percentage_List.append(Sub_Contract_Expenses_Industry_Percentage)
  #
  #       Cost_Of_Goods_Sold = ProfitAndLossSheet[Col][10]
  #       Cost_Of_Goods_Sold_Percentage = (Cost_Of_Goods_Sold/Revenue)*100
  #       Cost_Of_Goods_Sold_Percentage_List.append(Cost_Of_Goods_Sold_Percentage)
  #
  #       Cost_Of_Goods_Sold_Industry = ProfitAndLossSheet_Industry[Col][10]
  #       Cost_Of_Goods_Sold_Percentage_Industry = (Cost_Of_Goods_Sold_Industry/Revenue_Industry)*100
  #       Cost_Of_Goods_Sold_Percentage_Industry_List.append(Cost_Of_Goods_Sold_Percentage_Industry)
  #
  #       Gross_Profit_Percentage_List.append(Gross_Margin)
  #       Gross_Profit_Industry_Percentage_List.append(Gross_Margin_Industry)
  #
  #       Accounts_Payable = Balance_Sheet[Col][20]
  #       Accounts_Payable_Days = (Accounts_Payable * 365 / Cost_Of_Goods_Sold)
  #       Accounts_Payable_Days_List.append(Accounts_Payable_Days)
  #
  #       Accounts_Payable_Industry = Balance_Sheet_Industry[Col][20]
  #       Accounts_Payable_Days_Industry = (Accounts_Payable_Industry * 365 / Cost_Of_Goods_Sold_Industry)
  #       Accounts_Payable_Days_Industry_List.append(Accounts_Payable_Days_Industry)
  #
  #       Business_Development_Expenses = ProfitAndLossSheet[Col][13]
  #       Business_Development_Expenses_Percentage = (Business_Development_Expenses/Revenue)*100
  #       Business_Development_Expenses_Percentage_List.append(Business_Development_Expenses_Percentage)
  #
  #       Business_Development_Expenses_Industry = ProfitAndLossSheet_Industry[Col][13]
  #       Business_Development_Expenses_Industry_Percentage = (Business_Development_Expenses_Industry / Revenue_Industry) * 100
  #       Business_Development_Expenses_Industry_Percentage_List.append(Business_Development_Expenses_Industry_Percentage)
  #
  #       Fuel_Expenses = ProfitAndLossSheet[Col][14]
  #       Fuel_Expenses_Percentage = (Fuel_Expenses/Revenue)*100
  #       Fuel_Expenses_Percentage_List.append(Fuel_Expenses_Percentage)
  #
  #
  #       Fuel_Expenses_Industry = ProfitAndLossSheet_Industry[Col][14]
  #       Fuel_Expenses_Industry_Percentage = (Fuel_Expenses_Industry / Revenue_Industry) * 100
  #       Fuel_Expenses_Industry_Percentage_List.append(Fuel_Expenses_Industry_Percentage)
  #
  #
  #       Conveyance_Expenses = ProfitAndLossSheet[Col][15]
  #       Conveyance_Expenses_Percentage = (Conveyance_Expenses/Revenue)*100
  #       Conveyance_Expenses_Percentage_List.append(Conveyance_Expenses_Percentage)
  #
  #       Conveyance_Expenses_Industry = ProfitAndLossSheet_Industry[Col][15]
  #       Conveyance_Expenses_Industry_Percentage = (Conveyance_Expenses_Industry / Revenue_Industry) * 100
  #       Conveyance_Expenses_Industry_Percentage_List.append(Conveyance_Expenses_Industry_Percentage)
  #
  #       Telephone_Expenses = ProfitAndLossSheet[Col][16]
  #       Telephone_Expenses_Percentage = (Telephone_Expenses/Revenue)*100
  #       Telephone_Expenses_Percentage_List.append(Telephone_Expenses_Percentage)
  #
  #       Telephone_Expenses_Industry = ProfitAndLossSheet_Industry[Col][16]
  #       Telephone_Expenses_Industry_Percentage = (Telephone_Expenses_Industry / Revenue_Industry) * 100
  #       Telephone_Expenses_Industry_Percentage_List.append(Telephone_Expenses_Industry_Percentage)
  #
  #       Selling_And_Admin_Expenses = ProfitAndLossSheet[Col][18]
  #       Selling_And_Admin_Expenses_Percentage = (Selling_And_Admin_Expenses/Revenue)*100
  #       Selling_And_Admin_Expenses_Percentage_List.append(Selling_And_Admin_Expenses_Percentage)
  #
  #       Selling_And_Admin_Expenses_Industry = ProfitAndLossSheet_Industry[Col][18]
  #       Selling_And_Admin_Expenses_Industry_Percentage = (Selling_And_Admin_Expenses_Industry / Revenue_Industry) * 100
  #       Selling_And_Admin_Expenses_Industry_Percentage_List.append(Selling_And_Admin_Expenses_Industry_Percentage)
  #
  #       Electricity_Expenses = ProfitAndLossSheet[Col][20]
  #       Electricity_Expenses_Percentage = (Electricity_Expenses/Revenue)*100
  #       Electricity_Expenses_Percentage_List.append(Electricity_Expenses_Percentage)
  #
  #       Electricity_Expenses_Industry = ProfitAndLossSheet_Industry[Col][20]
  #       Electricity_Expenses_Industry_Percentage = (Electricity_Expenses_Industry / Revenue_Industry) * 100
  #       Electricity_Expenses_Industry_Percentage_List.append(Electricity_Expenses_Industry_Percentage)
  #
  #       Vehicle_Maintenance = ProfitAndLossSheet[Col][21]
  #       Vehicle_Maintenance_Percentage = (Vehicle_Maintenance/Revenue)*100
  #       Vehicle_Maintenance_Percentage_List.append(Vehicle_Maintenance_Percentage)
  #
  #       Vehicle_Maintenance_Industry = ProfitAndLossSheet_Industry[Col][21]
  #       Vehicle_Maintenance_Industry_Percentage = (Vehicle_Maintenance_Industry / Revenue_Industry) * 100
  #       Vehicle_Maintenance_Industry_Percentage_List.append(Vehicle_Maintenance_Industry_Percentage)
  #
  #       Machine_Maintenance = ProfitAndLossSheet[Col][22]
  #       Machine_Maintenance_Percentage = (Machine_Maintenance/Revenue)*100
  #       Machine_Maintenance_Percentage_List.append(Machine_Maintenance_Percentage)
  #
  #       Machine_Maintenance_Industry = ProfitAndLossSheet_Industry[Col][22]
  #       Machine_Maintenance_Industry_Percentage = (Machine_Maintenance_Industry / Revenue_Industry) * 100
  #       Machine_Maintenance_Industry_Percentage_List.append(Machine_Maintenance_Industry_Percentage)
  #
  #       Rent = ProfitAndLossSheet[Col][23]
  #       Rent_Percentage = (Rent/Revenue)*100
  #       Rent_Percentage_List.append(Rent_Percentage)
  #
  #       Rent_Industry = ProfitAndLossSheet_Industry[Col][23]
  #       Rent_Industry_Percentage = (Rent_Industry / Revenue_Industry) * 100
  #       Rent_Industry_Percentage_List.append(Rent_Industry_Percentage)
  #
  #       Consumables = ProfitAndLossSheet[Col][24]
  #       Consumables_Percentage = (Consumables / Revenue) * 100
  #       Consumables_Percentage_List.append(Consumables_Percentage)
  #
  #       Consumables_Industry = ProfitAndLossSheet_Industry[Col][24]
  #       Consumables_Industry_Percentage = (Consumables_Industry / Revenue_Industry) * 100
  #       Consumables_Industry_Percentage_List.append(Consumables_Industry_Percentage)
  #
  #       Bank_Charges = ProfitAndLossSheet[Col][25]
  #       Bank_Charges_Percentage = (Bank_Charges/Revenue)*100
  #       Bank_Charges_Percentage_List.append(Bank_Charges_Percentage)
  #
  #       Bank_Charges_Industry = ProfitAndLossSheet_Industry[Col][25]
  #       Bank_Charges_Industry_Percentage = (Bank_Charges_Industry / Revenue_Industry) * 100
  #       Bank_Charges_Industry_Percentage_List.append(Bank_Charges_Industry_Percentage)
  #
  #       Other_Operating_Expenses = ProfitAndLossSheet[Col][27]
  #       Other_Operating_Expenses_Percentage = (Other_Operating_Expenses / Revenue) * 100
  #       Other_Operating_Expenses_Percentage_List.append(Other_Operating_Expenses_Percentage)
  #
  #       Other_Operating_Expenses_Industry = ProfitAndLossSheet_Industry[Col][27]
  #       Other_Operating_Expenses_Industry_Percentage = (Other_Operating_Expenses_Industry / Revenue_Industry) * 100
  #       Other_Operating_Expenses_Industry_Percentage_List.append(Other_Operating_Expenses_Industry_Percentage)
  #
  #       EBITDA = ProfitAndLossSheet[Col][29]
  #       EBITDA_Percentage = (EBITDA/Revenue)*100
  #       EBITDA_Percentage_List.append(EBITDA_Percentage)
  #
  #       EBITDA_Industry = ProfitAndLossSheet_Industry[Col][29]
  #       EBITDA_Industry_Percentage = (EBITDA_Industry / Revenue_Industry) * 100
  #       EBITDA_Industry_Percentage_List.append(EBITDA_Industry_Percentage)
  #
  #       Depreciation_Expense = ProfitAndLossSheet[Col][31]
  #       Depreciation_Expense_Percentage = (Depreciation_Expense/Revenue)*100
  #       Depreciation_Expense_Percentage_List.append(Depreciation_Expense_Percentage)
  #
  #       Depreciation_Industry_Expense = ProfitAndLossSheet_Industry[Col][31]
  #       Depreciation_Industry_Expense_Percentage = (Depreciation_Industry_Expense / Revenue_Industry) * 100
  #       Depreciation_Industry_Expense_Percentage_List.append(Depreciation_Industry_Expense_Percentage)
  #
  #       Amortization_Expense = ProfitAndLossSheet[Col][32]
  #       Amortization_Expense_Percentage = (Amortization_Expense / Revenue) * 100
  #       Amortization_Expense_Percentage_List.append(Amortization_Expense_Percentage)
  #
  #       Amortization_Expense_Industry = ProfitAndLossSheet_Industry[Col][32]
  #       Amortization_Expense_Industry_Percentage = (Amortization_Expense_Industry / Revenue_Industry) * 100
  #       Amortization_Expense_Industry_Percentage_List.append(Amortization_Expense_Industry_Percentage)
  #
  #       Other_Expenses = ProfitAndLossSheet[Col][33]
  #       Other_Expenses_Percentage = (Other_Expenses / Revenue)*100
  #       Other_Expenses_Percentage_List.append(Other_Expenses_Percentage)
  #
  #       Other_Expenses_Industry = ProfitAndLossSheet_Industry[Col][33]
  #       Other_Expenses_Industry_Percentage = (Other_Expenses_Industry / Revenue_Industry) * 100
  #       Other_Expenses_Industry_Percentage_List.append(Other_Expenses_Industry_Percentage)
  #
  #       Operating_Profit = ProfitAndLossSheet[Col][35]
  #       Operating_Profit_Percentage = (Operating_Profit/Revenue)*100
  #       Operating_Profit_Percentage_List.append(Operating_Profit_Percentage)
  #
  #       Operating_Profit_Industry = ProfitAndLossSheet_Industry[Col][35]
  #       Operating_Profit_Industry_Percentage = (Operating_Profit_Industry / Revenue_Industry) * 100
  #       Operating_Profit_Industry_Percentage_List.append(Operating_Profit_Industry_Percentage)
  #
  #       Bank_Interest_Expense = ProfitAndLossSheet[Col][37]
  #       Bank_Interest_Expense_Percentage = (Bank_Interest_Expense/Revenue)*100
  #       Bank_Interest_Expense_Percentage_List.append(Bank_Interest_Expense_Percentage)
  #
  #       Bank_Interest_Expense_Industry = ProfitAndLossSheet_Industry[Col][37]
  #       Bank_Interest_Expense_Industry_Percentage = (Bank_Interest_Expense_Industry / Revenue_Industry) * 100
  #       Bank_Interest_Expense_Industry_Percentage_List.append(Bank_Interest_Expense_Industry_Percentage)
  #
  #       Other_Interest_Expense = ProfitAndLossSheet[Col][38]
  #       Other_Interest_Expense_Percentage = (Other_Interest_Expense / Revenue) * 100
  #       Other_Interest_Expense_Percentage_List.append(Other_Interest_Expense_Percentage)
  #
  #       Other_Interest_Expense_Industry = ProfitAndLossSheet[Col][38]
  #       Other_Interest_Expense_Industry_Percentage = (Other_Interest_Expense_Industry / Revenue_Industry) * 100
  #       Other_Interest_Expense_Industry_Percentage_List.append(Other_Interest_Expense_Industry_Percentage)
  #
  #       Total_Interest_Expense = ProfitAndLossSheet[Col][40]
  #       Total_Interest_Expense_Percentage = (Total_Interest_Expense/Revenue)*100
  #       Total_Interest_Expense_Percentage_List.append(Total_Interest_Expense_Percentage)
  #
  #       Total_Interest_Expense_Industry = ProfitAndLossSheet_Industry[Col][40]
  #       Total_Interest_Expense_Industry_Percentage = (Total_Interest_Expense_Industry / Revenue_Industry) * 100
  #       Total_Interest_Expense_Industry_Percentage_List.append(Total_Interest_Expense_Industry_Percentage)
  #
  #       Interest_Expense_Per_Working_Hour = Total_Interest_Expense/2592
  #       Interest_Expense_Per_Working_Hour_List.append(Interest_Expense_Per_Working_Hour)
  #
  #       Interest_Expense_Industry_Per_Working_Hour = Total_Interest_Expense_Industry / 2592
  #       Interest_Expense_Industry_Per_Working_Hour_List.append(Interest_Expense_Industry_Per_Working_Hour)
  #
  #       Bank_Interest_Income = ProfitAndLossSheet[Col][42]
  #       Bank_Interest_Income_Percentage = (Bank_Interest_Income/Revenue)*100
  #       Bank_Interest_Income_Percentage_List.append(Bank_Interest_Income_Percentage)
  #
  #       Bank_Interest_Income_Industry = ProfitAndLossSheet_Industry[Col][42]
  #       Bank_Interest_Income_Industry_Percentage = (Bank_Interest_Income_Industry / Revenue_Industry) * 100
  #       Bank_Interest_Income_Industry_Percentage_List.append(Bank_Interest_Income_Industry_Percentage)
  #
  #       other_income = ProfitAndLossSheet[Col][43]
  #       other_income_Percentage = (other_income/Revenue)*100
  #       other_income_Percentage_List.append(other_income_Percentage)
  #
  #       other_income_Industry = ProfitAndLossSheet_Industry[Col][43]
  #       other_income_Industry_Percentage = (other_income_Industry / Revenue_Industry) * 100
  #       other_income_Industry_Percentage_List.append(other_income_Industry_Percentage)
  #
  #       Total_Interest_Income = ProfitAndLossSheet[Col][45]
  #       Total_Interest_Income_Percentage = (Total_Interest_Income / Revenue) * 100
  #       Total_Interest_Income_Percentage_List.append(Total_Interest_Income_Percentage)
  #
  #       Total_Interest_Income_Industry = ProfitAndLossSheet_Industry[Col][45]
  #       Total_Interest_Income_Industry_Percentage = (Total_Interest_Income_Industry / Revenue) * 100
  #       Total_Interest_Income_Industry_Percentage_List.append(Total_Interest_Income_Industry_Percentage)
  #
  #       Net_Income_Before_Taxes = ProfitAndLossSheet[Col][47]
  #       Net_Income_Before_Taxes_Percentage = (Net_Income_Before_Taxes/Revenue)*100
  #       Net_Income_Before_Taxes_Percentage_List.append(Net_Income_Before_Taxes_Percentage)
  #
  #       Net_Income_Before_Taxes_Industry = ProfitAndLossSheet_Industry[Col][47]
  #       Net_Income_Before_Taxes_Industry_Percentage = (Net_Income_Before_Taxes_Industry / Revenue_Industry) * 100
  #       Net_Income_Before_Taxes_Industry_Percentage_List.append(Net_Income_Before_Taxes_Industry_Percentage)
  #
  #       Income_Tax_Expense = ProfitAndLossSheet[Col][49]
  #       Income_Tax_Expense_Percentage = (Income_Tax_Expense/Revenue)*100
  #       Income_Tax_Expense_Percentage_List.append(Income_Tax_Expense_Percentage)
  #
  #       Income_Tax_Expense_Industry = ProfitAndLossSheet_Industry[Col][49]
  #       Income_Tax_Expense_Industry_Percentage = (Income_Tax_Expense_Industry / Revenue_Industry) * 100
  #       Income_Tax_Expense_Industry_Percentage_List.append(Income_Tax_Expense_Industry_Percentage)
  #
  #       Net_Income = ProfitAndLossSheet[Col][51]
  #       Net_Income_Percentage = (Net_Income/Revenue)*100
  #       Net_Income_Percentage_List.append(Net_Income_Percentage)
  #
  #       Net_Income_Industry = ProfitAndLossSheet_Industry[Col][51]
  #       Net_Income_Industry_Percentage = (Net_Income_Industry / Revenue_Industry) * 100
  #       Net_Income_Industry_Percentage_List.append(Net_Income_Industry_Percentage)