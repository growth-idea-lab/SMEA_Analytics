def send_email(status, userId):
    get_email(userId)

    FROM = 'growthidealab@gmail.com'
    msg = MIMEMultipart()

    print 'Sending Email'
    if status:
        msg['Subject'] = 'Your Financial report is generated .'
    else:
        msg['Subject'] = 'Please revisit to update the data correctly for analysis'

    msg['From'] = FROM
    msg['To'] = ', '.join(EMAIL_LIST)
    s = smtplib.SMTP('localhost')
    s.sendmail(FROM, userEmail, msg.as_string())
    s.quit()