module.exports = function(grunt) {
    // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    uglify: {
      build: {
        src: ['app/**/*.js', 'app/**/*.js' ],
        dest: 'dist/js/<%= pkg.name %>.min.js'
      }
    },
    cssmin: {
      options: {
        mergeIntoShorthands: false,
        roundingPrecision: -1
      },
      target: {
        files: {
          'dist/css/<%= pkg.name %>.min.css': ['app/app.css']
        }
      }
    },

    preprocess : {
        html : {
            src : 'app/index.html',
            dest : 'dist/index.html'
        },
    },
    copy: {
      main: {
        src: ['content/*.*', 'app/components/**/*.html'],
        dest: 'dist/',
      },
      local: {
        src: ['content/*.*', 'app/components/**/*.html', 'server.js'],
        dest: 'dist/',
      },
    }
  });


  // Load the plugin that provides the task.
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-preprocess');
  grunt.loadNpmTasks('grunt-contrib-copy');

  // Default task(s).
  grunt.registerTask('default', ['uglify', 'cssmin', 'preprocess', 'copy:local']);
  grunt.registerTask('dev', ['uglify', 'cssmin', 'preprocess', 'copy:main']);
}