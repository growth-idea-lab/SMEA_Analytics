'use strict';

// Declare app level module which depends on views, and components
var app = angular.module('SMEApp', ['ui.router']);
app.config(['$stateProvider', '$urlRouterProvider', '$locationProvider', function($stateProvider, $urlRouterProvider, $locationProvider) {

    $stateProvider
        .state('login', {
            url: '/login',
            template: '<login></login>'
        })
        .state('signup', {
            url: '/',
            template: '<signup></signup>'
        })
        .state('upload', {
            url: '/upload',
            template: '<upload></upload>'
        })
        .state('confirm', {
            url: '/confirm',
            template: '<confirm-data></confirm-data>'
        })
        .state('data', {
            url: '/data',
            template: '<data></data>',
        })
        .state('email', {
            url: '/email',
            template: '<email></email>',
        })

    $urlRouterProvider.otherwise('/');
    $locationProvider.html5Mode(true);
}]);