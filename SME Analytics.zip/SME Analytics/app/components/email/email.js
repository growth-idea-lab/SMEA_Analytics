angular.module('SMEApp').component('email', {
    templateUrl: 'app/components/email/email.html',
    controller: 'emailCtrl'
 });