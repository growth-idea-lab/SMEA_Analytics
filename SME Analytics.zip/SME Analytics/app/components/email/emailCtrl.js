(function(){
    angular.module('SMEApp').controller('emailCtrl',['$http', '$state', 'dataService', function($http, $state, dataService) {
        var ctrl = this;
        ctrl.email = '';
        ctrl.login = function() {
            var pwdBitArray = sjcl.hash.sha256.hash(ctrl.password);
            // convert in node js
            var passwordHash = sjcl.codec.hex.fromBits(pwdBitArray);
            $http.post('http://localhost:8080/login', {
                userId: ctrl.userId,
                password: passwordHash,
            }).then(function(response) {
                if (response.data === "Success") {
                    dataService.userId = ctrl.userId;
                    $state.go('upload');
                }
            });
        };

        ctrl.sendEmail = function() {
            var link = document.createElement("a");
            link.download = 'ratios.docx';
            link.href = 'content/ratios.docx';
            link.click();
            $('#success')[0].style.display = 'block';
        };
    }]);
})();