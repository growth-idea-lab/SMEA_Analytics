(function(){
    angular.module('SMEApp').controller('confirmDataCtrl', ['$state', 'dataService', function($state, dataService) {
        var ctrl = this;
        function init() {
            ctrl.finalObj = {};
            ctrl.userId = dataService.userId;
            ctrl.sheetTypes = _.keys(dataService.excelData);
            _.each(ctrl.sheetTypes, function(sheetType){
                ctrl.finalObj[sheetType] = {};
                var sheetData = dataService.excelData[sheetType];
                _.each(sheetData, function(dataEntry) {
                    var input = _.filter(_.keys(dataEntry), function(value) {
                        return _.isNaN(parseInt(value));
                    });
                    var years = _.filter(_.keys(dataEntry), function(value) {
                        return !_.isNaN(parseInt(value));
                    });

                    _.each(years, function(year) {
                        if (_.isUndefined(ctrl.finalObj[sheetType][year])) {
                            ctrl.finalObj[sheetType][year] = {};
                        }
                        ctrl.finalObj[sheetType][year][dataEntry[input]] = dataEntry[year];
                    });
                });
            });
            ctrl.selectSheet(ctrl.sheetTypes[0]);
        }

        ctrl.selectSheet = function(sheet) {
            ctrl.selectedSheet = sheet;
            ctrl.years = _.keys(ctrl.finalObj[sheet]);
            ctrl.selectedYear = ctrl.years[0];
            ctrl.selectYear(ctrl.selectedYear);
        };

        ctrl.selectYear = function(year) {
            ctrl.selectedYear = year;
            ctrl.dataList = _.keys(ctrl.finalObj[ctrl.selectedSheet][ctrl.selectedYear]);
        };

        ctrl.submit = function() {
            $state.go('email');
        };

        init();
    }]);
})();
