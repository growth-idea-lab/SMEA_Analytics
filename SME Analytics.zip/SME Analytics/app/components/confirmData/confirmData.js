angular.module('SMEApp').component('confirmData', {
    templateUrl: 'app/components/confirmData/confirmData.html',
    controller: 'confirmDataCtrl'
 });