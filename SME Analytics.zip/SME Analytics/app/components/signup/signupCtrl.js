(function(){
    angular.module('SMEApp').controller('signupCtrl',['$http', '$state', function($http, $state) {
        var ctrl = this;
        ctrl.signup = function() {
            if (ctrl.password !== ctrl.password2) {
                ctrl.showWarning = true;
                ctrl.warningMessage = "The passwords do not match. Please confirm password correctly.";
            } else if ((ctrl.email.indexOf('@') < 1) || (ctrl.email.indexOf('.com') < 3)) {
                ctrl.showWarning = true;
                ctrl.warningMessage = "Please enter a valid email.";
            } else {
                var pwdBitArray = sjcl.hash.sha256.hash(ctrl.password);
                // convert in node js
                var passwordHash = sjcl.codec.hex.fromBits(pwdBitArray);
                $http.post('http://localhost:8080/signup', {
                    userId: ctrl.userId,
                    email: ctrl.email,
                    password: passwordHash,
                    question: $('#hintQuestion')[0].value,
                    answer: ctrl.answer,
                }).then(function(response) {
                    if (response.data == "Success") {
                        $state.go('login');
                    }
                });
            }
        };
    }]);
})();
