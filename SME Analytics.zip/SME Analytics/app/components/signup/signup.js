angular.module('SMEApp').component('signup', {
    templateUrl: 'app/components/signup/signup.html',
    controller: 'signupCtrl'
 });