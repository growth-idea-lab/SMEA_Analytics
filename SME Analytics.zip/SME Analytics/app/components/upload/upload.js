angular.module('SMEApp').component('upload', {
    templateUrl: 'app/components/upload/upload.html',
    controller: 'uploadCtrl'
});