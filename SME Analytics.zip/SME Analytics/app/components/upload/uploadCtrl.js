(function(){
    angular.module('SMEApp').controller('uploadCtrl', ['$state', 'dataService', function($state, dataService) {
        var ctrl = this;
        ctrl.parseExcel = function(file) {
            ctrl.convertedExcel = {};
            var reader = new FileReader();
        
            reader.onload = function(e) {
              var data = e.target.result;
              var workbook = XLSX.read(data, {
                type: 'binary',
              });
        
              workbook.SheetNames.forEach(function(sheetName) {
                // Here is your file data
                ctrl.convertedExcel[sheetName] = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
              });
              
            };
        
            reader.onerror = function(ex) {
              console.log(ex);
            };
        
            reader.readAsBinaryString(file);
        };

        ctrl.uploadFile = function(){
            ctrl.file = document.getElementById("inputFile").files[0];
            ctrl.parseExcel(ctrl.file);
            dataService.excelData = ctrl.convertedExcel;
            $state.go('confirm');
        };

        ctrl.downloadTemplate = function() {
            var link = document.createElement("a");
            link.download = 'template.xlsx';
            link.href = 'content/template.xlsx';
            link.click();
        };
    }]);
})();