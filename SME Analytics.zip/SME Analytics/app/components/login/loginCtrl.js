(function(){
    angular.module('SMEApp').controller('loginCtrl',['$http', '$state', 'dataService', function($http, $state, dataService) {
        var ctrl = this;
        ctrl.login = function() {
            var pwdBitArray = sjcl.hash.sha256.hash(ctrl.password);
            // convert in node js
            var passwordHash = sjcl.codec.hex.fromBits(pwdBitArray);
            $http.post('http://localhost:8080/login', {
                userId: ctrl.userId,
                password: passwordHash,
            }).then(function(response) {
                if (response.data === "Success") {
                    dataService.userId = ctrl.userId;
                    $state.go('upload');
                }
            });
        };
    }]);
})();
