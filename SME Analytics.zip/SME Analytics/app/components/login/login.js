angular.module('SMEApp').component('login', {
    templateUrl: 'app/components/login/login.html',
    controller: 'loginCtrl'
 });