(function(){
    angular.module('SMEApp').service('dataService', function() {
        var service = {};
        service.excelData = {};
        service.userId = {};
    });
})();